using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using Unity.VisualScripting;

public class EnemyGFX : MonoBehaviour
{
    public AIPath aiPath;
    public Animator animator;
    private GameObject enemy;
    // Update is called once per frame
    void Update()
    {
        float x = aiPath.destination.x;
        float y = aiPath.destination.y;
        float speed = aiPath.destination.sqrMagnitude;
        //todo

        animator.SetFloat("Horizontal", x);
        animator.SetFloat("Vertical", y);
        animator.SetFloat("Speed", speed);

        

    }
}

using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class Key : InteractableObject
{
    //[SerializeField] public GameObject[] keys;
    [SerializeField] private ToolClass keyData;
    [SerializeField] private GameObject inventoryController;
    [SerializeField] private int keyNum;
    protected override void OnInteract()
    {
        base.OnInteract();
        keyData.toolID = keyNum;
        keyData.itemName = name;
        keyData.icon = GetComponent<SpriteRenderer>().sprite;
        inventoryController.GetComponent<InventoryController>().Add(keyData);
        gameObject.SetActive(false);

    }
}

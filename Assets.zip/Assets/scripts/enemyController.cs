using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.TextCore.Text;

public class EnemyController : MonoBehaviour
{
    //[SerializeField] private CircleCollider2D viewCollider;
    public GameObject Player;
    [SerializeField] [Range(0,4)] private int moveSpeed = 4;
    [SerializeField] [Range(0,3)] private float viewRange;
    void Start()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        //Debug.Log("I SEE YOU!!!!");
    }
    // Start is called before the first frame update


    // Update is called once per frame
    void Update()
    {
        float distance = Vector2.Distance(transform.position, Player.transform.position);

        Debug.Log($"{name} is {distance}f away");
        if (distance < viewRange)
        {

            transform.position = Vector2.MoveTowards(transform.position, Player.transform.position, moveSpeed * Time.deltaTime);



        }
    }
}

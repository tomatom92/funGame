using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEditor.Progress;

public class Bomb : InteractableObject
{

    
    [SerializeField]
    public MiscClass bombData;
    public GameObject inventoryController;

    public void Collect()
    {
        Destroy(gameObject);
        Debug.Log($"entered trigger {GetComponent<Collider>().gameObject.name}");
    }
    protected override private void OnTriggerEnter2D(Collider2D other)
    {
        inventoryController.GetComponent<InventoryController>().Add(bombData);
        

        gameObject.SetActive(false);


    }
}

using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.U2D.Aseprite;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MapManager : MonoBehaviour
{
    [HideInInspector]
    public static MapManager instance;
    [SerializeField]
    public Tilemap map;
    [SerializeField]
    public Tilemap mapEnvironment;
    [SerializeField]
    protected GameObject player;

    [SerializeField]
    protected List<TileData> tileDatas;

    protected Dictionary<TileBase, TileData> dataFromTiles;

    protected virtual void Awake()
    {
        dataFromTiles = new Dictionary<TileBase, TileData>();
        foreach (var tileData in tileDatas)
        {
            foreach (var tile in tileData.tiles)
            {
                dataFromTiles.Add(tile, tileData);
            }
        }
    }
    void Update()
    {
        Vector2 playerPos = player.transform.position;
        Vector3Int playerCellPos = map.WorldToCell(playerPos);
        //Debug.Log(playerCellPos);
        
        TileBase currentTile = map.GetTile(playerCellPos);
        if (currentTile)
        {
            
            //main to cave
            WormHole(currentTile, new Vector3Int(3,14), new Vector3Int(-26,1));
            WormHole(currentTile, new Vector3Int(-26, 0), new Vector3Int(3, 13));

            //main(8,12) to temple(29,10)
            WormHole(currentTile, new Vector3Int(8, 12), new Vector3Int(29, 8));
            WormHole(currentTile, new Vector3Int(29, 10), new Vector3Int(8, 11));

            //main(7,21) to tower(29,10)
            WormHole(currentTile, new Vector3Int(8, 12), new Vector3Int(29, 8));
            WormHole(currentTile, new Vector3Int(29, 10), new Vector3Int(8, 11));





        }

        








    }
    private void WormHole(TileBase currentTile , Vector3Int startTilePos, Vector3Int endTilePos)
    {
        Vector2 playerPos = player.transform.position;
        Vector3Int playerCellPos = map.WorldToCell(playerPos);
        TileBase startTile = map.GetTile(startTilePos);
        if (currentTile == startTile && playerCellPos == startTilePos)
        {
            player.transform.position = map.GetCellCenterWorld(endTilePos);
        }

    }
    public TileData GetTileData(Vector3Int tilePosition)
    {
        TileBase tile = map.GetTile(tilePosition);
        if (tile == null)
            return null;
        else
            return dataFromTiles[tile];
    }
    
    
}

using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Tilemaps;

public class ChestController : InteractableObject
{
    
    
    [SerializeField] private Animator animator;

    [SerializeField] private int chestID;
    [SerializeField] private GameObject item;

    private void Awake()
    {
        item.SetActive(false);
        item.transform.position = transform.position;
    }
    protected override void Update()
    {
        base.Update();

        if (z_interacted)
        {
            item.SetActive(true);
            animator.SetBool("IsOpen", true);
            GetComponent<BoxCollider2D>().enabled = false;
            
        }

    }
}

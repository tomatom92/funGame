using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletController : InteractableObject
{
    protected override private void OnCollided(GameObject collidedObject)
    {
        if (collidedObject.tag == "Enemy" )
        {
            base.OnCollided(collidedObject);
            Destroy(collidedObject);
        }
    }
}

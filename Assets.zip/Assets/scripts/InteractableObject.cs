using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractableObject : CollidableObject
{
    protected bool z_interacted = false;
    [SerializeField] protected bool z_disappear;
    

    protected override private void OnCollided(GameObject collidedObject)
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            base.OnCollided(collidedObject);
            OnInteract();
        }
    }
    protected virtual void OnInteract()
    {
        Debug.Log("interacted with " + name);
        if (!z_interacted)
        {
            z_interacted = true;
            Debug.Log("z_interacted = true");
        }
        



    }
    protected virtual private void OnTriggerEnter2D(Collider2D collider)
    {
        Debug.Log($"entered trigger {collider.gameObject.name}");
    }
}

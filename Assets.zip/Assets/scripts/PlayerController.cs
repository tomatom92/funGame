using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class PlayerController : MonoBehaviour
{


    [SerializeField] private SpriteRenderer spriteRenderer;
    public float moveSpeed = 5f;
    public bool isSprinting;
    public float sprintSpeed;


    private Vector2 movement;

    [SerializeField] PlayerInputActions playerControls;

    [SerializeField] private GameObject player, weapon;


    [SerializeField] private Animator animator;

    [SerializeField] private float meleeSpeed;

    [SerializeField] private float damage;

    [SerializeField] private Tilemap map;

    [SerializeField] public GameObject[] keys;

    private InputAction move;
    private InputAction fire;
    private InputAction interact;
    private InputAction sprint;
    private InputAction sprintRelease;
    private GameObject sword;

    private float attackCooldown = 0;
    private float attackRange = 0.5f;
    private Transform _transform;

    private void Awake()
    {
        _transform = transform;
        playerControls = new PlayerInputActions();
        //sword = player.transform.GetChild(0).gameObject;
        //sword.SetActive(false);

        

    }

    private void Update()
    {

        // getting moveement inputs and sending to animator

        movement = move.ReadValue<Vector2>();

        animator.SetFloat("Horizontal", movement.x);
        animator.SetFloat("Vertical", movement.y);
        animator.SetFloat("Speed", movement.sqrMagnitude);

        //flipping sprite
        if (animator.GetFloat("Horizontal") > 0)
        {
            spriteRenderer.flipX = true;
        }
        else
        {
            spriteRenderer.flipX = false;
        }
        //sprinting
        



    }
    private Rigidbody2D rb;
    void FixedUpdate()
    {
        //actual movement here
        //sprinting
        if (isSprinting) { rb.MovePosition(rb.position + movement.normalized * sprintSpeed * Time.fixedDeltaTime); }
        //walking
        else { rb.MovePosition(rb.position + movement.normalized * moveSpeed * Time.fixedDeltaTime); }
            


    }
    void Start()
    {

        float sprintSpeed = moveSpeed * 1.5f;
        rb = GetComponent<Rigidbody2D>();


    }


    
    private void OnEnable()
    {
        
        move = playerControls.Player.Move;
        move.Enable();
        fire = playerControls.Player.Fire;
        fire.Enable();
        fire.performed += Fire;
        interact = playerControls.Player.Interact;
        interact.Enable();
        interact.performed += Interact;
        sprint = playerControls.Player.Sprint;
        sprint.Enable();
        sprint.performed += Sprint;
        sprintRelease = playerControls.Player.SprintRelease;
        sprintRelease.Enable();
        sprintRelease.performed += SprintRelease;
        
        
    }
    private void OnDisable()
    {
        sprint.Disable();
        move.Disable();
        fire.Disable();
        interact.Disable();
    }



    
    private void Fire(InputAction.CallbackContext context)
    {
        //detect enemies;
        if(Physics2D.OverlapCircle(new Vector2(1, 2), 2f) != null){

        }
        float x = animator.GetFloat("Horizontal");
        float y = animator.GetFloat("Vertical");

        if (attackCooldown <= 0)
        {

            attackCooldown = meleeSpeed;
        }
        else
        {
            attackCooldown -= Time.deltaTime;
        }


        



        Debug.Log("fired");
    }
    private void Interact(InputAction.CallbackContext context)
    {
        //calling interactableobject method
        Debug.Log("interact");


        float x = animator.GetFloat("Horizontal");
        float y = animator.GetFloat("Vertical");
        //raycast
        //right
        if (x > 0)
        {

            //Bullet

            RaycastHit2D raycastHit2D = Physics2D.Raycast(player.transform.position, player.transform.right);
            if (raycastHit2D)
            {
                Vector3Int rayPos = map.WorldToCell(raycastHit2D.collider.transform.position);
                //draw test line
                Debug.Log("hit at " + rayPos);
                Debug.DrawLine(player.transform.position, raycastHit2D.collider.transform.position, Color.red, 2f);
            }
        }
        //left
        else if (x < 0)
        {
            RaycastHit2D raycastHit2D = Physics2D.Raycast(player.transform.position, -player.transform.right);
            if (raycastHit2D)
            {
                if (map.WorldToCell(raycastHit2D.transform.position) != null)
                {
                    Vector3Int rayPos = map.WorldToCell(raycastHit2D.transform.position);
                    Debug.Log("hit at " + rayPos);
                    Debug.DrawLine(player.transform.position, raycastHit2D.collider.transform.position, Color.red, 2f);
                }
            }
        }
        //up
        if (y > 0)
        {
            RaycastHit2D raycastHit2D = Physics2D.Raycast(player.transform.position, player.transform.up);
            if (raycastHit2D)
            {

                if (map.WorldToCell(raycastHit2D.transform.position) != null)
                {
                    Vector3Int rayPos = map.WorldToCell(raycastHit2D.transform.position);
                    Debug.Log("hit at " + rayPos);
                    Debug.DrawLine(player.transform.position, raycastHit2D.collider.transform.position, Color.red, 2f);
                }
            }
        }
        //down
        else if (y < 0)
        {
            //moving raycast down because it hits player

            RaycastHit2D raycastHit2D = Physics2D.Raycast(player.transform.position - Vector3.up, -player.transform.up);
            if (raycastHit2D)
            {
                if (map.WorldToCell(raycastHit2D.transform.position) != null)
                {
                    Vector3Int rayPos = map.WorldToCell(raycastHit2D.transform.position);
                    Debug.Log("hit at " + rayPos);
                    Debug.DrawLine(player.transform.position, raycastHit2D.collider.transform.position, Color.red, 2f);
                }


            }



        }

    }

    private void Sprint(InputAction.CallbackContext context)
    {
        Debug.Log("sprinting");
        isSprinting = true;
    }
    private void SprintRelease(InputAction.CallbackContext context)
    {
        isSprinting = false;
    }
}

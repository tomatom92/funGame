using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;
using static UnityEditor.Progress;


public class DoorManager : MapManager
{
    private TilemapCollider2D z_collider;
    [SerializeField]
    private ContactFilter2D z_filter;
    [SerializeField]
    private Tile[] doors;
    [SerializeField]
    private Tile doorOpenedSprite;
    [SerializeField]
    private InventoryController inventory;

    

    private ToolClass[] keys;

    private void Start()
    {
        z_collider = GetComponent<TilemapCollider2D>();
    }
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (true)
            {

            }
        }

    }
    public void OpenDoor(Vector3Int tilePosition)
    {
        Vector2 playerPos = player.transform.position;
        Vector3Int playerCellPos = map.WorldToCell(playerPos);
        if (GetTileData(tilePosition) != null) {
            //replace with if green key is obtained
            InventorySlot temp = inventory.Contains(keys[0]);
            if (true)
            {

            }
        }
        
    }
}

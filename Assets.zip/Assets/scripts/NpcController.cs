using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcController : InteractableObject
{
    [SerializeField] private GameObject player;
    private NpcController instance;
    private float distance;

    protected override void OnInteract()
    {
        base.OnInteract();
        transform.GetChild(0).gameObject.SetActive(true);
        instance = this;

    }
    protected override void Update()
    {
        base.Update();
        if (instance != null)
        {
            //instance.distance = Vector2.Distance(instance.transform.position, player.transform.position);
            //Debug.Log($"npc: {instance.gameObject.name} is {instance.distance} away");
            //if (instance.distance > 2f)
            //{

            //    transform.GetChild(0).gameObject.SetActive(false);
            //}
        }

    }
}
